#include <gtk/gtk.h>
#include <glib.h>
#include <signal.h>
#include <ifaddrs.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

GtkWidget *text_view;
GtkTextBuffer *buffer;

GPid server_pid = 0;
GIOChannel *server_out = NULL;

/* log */
void append_log(const char *text)
{
    GtkTextIter end;
    gtk_text_buffer_get_end_iter(buffer, &end);
    gtk_text_buffer_insert(buffer, &end, text, -1);
}

gboolean check_internet()
{
    struct sockaddr_in sa;
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) return FALSE;

    sa.sin_family = AF_INET;
    sa.sin_port = htons(53); // DNS port
    inet_pton(AF_INET, "8.8.8.8", &sa.sin_addr);

    struct timeval tv;
    tv.tv_sec = 2;  // 2-second timeout
    tv.tv_usec = 0;
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tv, sizeof tv);
    setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, (const char*)&tv, sizeof tv);

    int connected = connect(sock, (struct sockaddr*)&sa, sizeof(sa));
    close(sock);

    return connected == 0;
}

char *get_lan_ip()
{
    struct ifaddrs *ifaddr, *ifa;
    static char ip[INET_ADDRSTRLEN];

    if (getifaddrs(&ifaddr) == -1)
        return NULL;

    for (ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next)
    {
        if (ifa->ifa_addr == NULL)
            continue;

        if (ifa->ifa_addr->sa_family == AF_INET)
        {
            void *addr = &((struct sockaddr_in *)ifa->ifa_addr)->sin_addr;
            inet_ntop(AF_INET, addr, ip, INET_ADDRSTRLEN);

            /* skip localhost */
            if (g_strcmp0(ip, "127.0.0.1") != 0)
            {
                freeifaddrs(ifaddr);
                return ip;
            }
        }
    }

    freeifaddrs(ifaddr);
    return NULL;
}

/* read output */
gboolean read_server_output(GIOChannel *source, GIOCondition cond, gpointer data)
{
    gchar *line = NULL;
    gsize len;

    if (g_io_channel_read_line(source, &line, &len, NULL, NULL) == G_IO_STATUS_NORMAL)
    {
        if (g_strrstr(line, "Running on"))
        {
            /* find last ':' (before port) */
            char *last_colon = strrchr(line, ':');

            if (last_colon != NULL)
            {
                int port = atoi(last_colon + 1);

                char *lan_ip = get_lan_ip();

                if (lan_ip != NULL && port > 0)
                {
                    gchar output[128];
                    snprintf(output, sizeof(output),
                             "🌐 Server running at: %s:%d\n",
                             lan_ip, port);

                    append_log(output);
                }
                else
                {
                    append_log("⚠️ Failed to parse IP/port\n");
                }
            }
        }
        else
        {
            append_log(line);
        }

        g_free(line);
    }

    return TRUE;
}

/* check imports */
void check_python_imports(const char *python)
{
    append_log("Checking Python modules...\n");

    gchar *argv[] = {
        (char *)python,
        "-c",
        "import subprocess, json, threading, time; from flask import Flask",
        NULL
    };

    gint status;
    GError *error = NULL;

    gboolean ok = g_spawn_sync(
        NULL,
        argv,
        NULL,
        0,
        NULL,
        NULL,
        NULL,
        NULL,
        &status,
        &error
    );

    if (!ok)
    {
        append_log("❌ Failed to check modules\n");
        append_log(error->message);
        append_log("\n");
        g_error_free(error);
        return;
    }

    if (status == 0)
    {
        append_log("✅ All modules installed\n\n");
    }
    else
    {
        append_log("❌ Missing modules (Flask likely missing)\n");
        append_log("Install with: pip install flask\n\n");
    }
}

/* startup checks */
void run_checks()
{
    append_log("Checking environment...\n");

    gchar *python = g_find_program_in_path("python3");

    if (python == NULL)
    {
        append_log("❌ Python3 not found\n");
        append_log("Install: sudo dnf install python3\n\n");
        return;
    }

    append_log("✅ Python found: ");
    append_log(python);
    append_log("\n");

    if (!g_file_test("./phlush_server.py", G_FILE_TEST_EXISTS))
    {
        append_log("❌ phlush_server.py not found\n\n");
        return;
    }

    append_log("✅ Server file found\n");

    check_python_imports(python);

    append_log("Environment ready\n\n");
}

/* start server */
void start_server(GtkWidget *widget, gpointer data)
{

    if (!check_internet())
    {
        append_log("❌ No internet connection. Cannot start server.\n");
        return;
    }

    if (server_pid != 0)
    {
        append_log("Server already running\n");
        return;
    }

    gchar *python = g_find_program_in_path("python3");

    if (python == NULL)
    {
        append_log("Python missing\n");
        return;
    }

    if (!g_file_test("./phlush_server.py", G_FILE_TEST_EXISTS))
    {
        append_log("Server file missing\n");
        return;
    }

    append_log("Starting server...\n");

    gchar *argv[] = {
        python,
        "-u",
        "./phlush_server.py",
        NULL
    };

    gint out_fd;
    GError *error = NULL;

    gboolean ok = g_spawn_async_with_pipes(
        NULL,
        argv,
        NULL,
        G_SPAWN_DO_NOT_REAP_CHILD,
        NULL,
        NULL,
        &server_pid,
        NULL,
        &out_fd,
        &out_fd,
        &error
    );

    if (!ok)
    {
        append_log("❌ Failed to start server:\n");
        append_log(error->message);
        append_log("\n");
        g_error_free(error);
        return;
    }

    append_log("✅ Server started\n");

    char *lan_ip = get_lan_ip();

    if (lan_ip != NULL)
    {
        gchar output[128];
        snprintf(output, sizeof(output),
                "🌐 Server running at: %s:5000\n",  // <-- your port here
                lan_ip);

        append_log(output);
    }
    else
    {
        append_log("⚠️ Could not detect LAN IP\n");
    }

    server_out = g_io_channel_unix_new(out_fd);
    g_io_add_watch(server_out, G_IO_IN | G_IO_HUP, read_server_output, NULL);
}

/* stop server */
void stop_server(GtkWidget *widget, gpointer data)
{
    if (server_pid == 0)
    {
        append_log("Server not running\n");
        return;
    }

    kill(server_pid, SIGTERM);

    append_log("Server stopped\n");

    server_pid = 0;
}

/* main */
int main(int argc, char *argv[])
{
    gtk_init(&argc, &argv);

    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "phlush | server manager");
    gtk_window_set_default_size(GTK_WINDOW(window), 700, 450);

    GtkWidget *vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    GtkWidget *scroll = gtk_scrolled_window_new(NULL, NULL);
    gtk_box_pack_start(GTK_BOX(vbox), scroll, TRUE, TRUE, 0);

    text_view = gtk_text_view_new();
    gtk_text_view_set_editable(GTK_TEXT_VIEW(text_view), FALSE);

    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(text_view));
    gtk_container_add(GTK_CONTAINER(scroll), text_view);

    /* RUN CHECKS ON START */
    run_checks();

    GtkWidget *hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 10);
    gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 10);

    GtkWidget *start_btn = gtk_button_new_with_label("Start Server");
    GtkWidget *stop_btn = gtk_button_new_with_label("Stop Server");

    gtk_box_pack_start(GTK_BOX(hbox), start_btn, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(hbox), stop_btn, TRUE, TRUE, 0);

    g_signal_connect(start_btn, "clicked", G_CALLBACK(start_server), NULL);
    g_signal_connect(stop_btn, "clicked", G_CALLBACK(stop_server), NULL);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    gtk_widget_show_all(window);
    gtk_main();

    return 0;
}
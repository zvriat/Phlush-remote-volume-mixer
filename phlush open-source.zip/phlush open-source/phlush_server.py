import subprocess, json, threading, time
from flask import Flask, jsonify, request, send_from_directory
import logging, socket

app = Flask(__name__, static_folder="web")

log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)




apps_cache = {}        # key=proc_name, value={id_list, name, volume, muted}
desired_volumes = {}   # key=proc_name, value=volume (0-1)
metadata_override = {} # key=proc_name, value=title from browser

# --- Fetch sink inputs and group by process ---
def get_apps():
    try:
        result = subprocess.run(
            ["pactl", "-f", "json", "list", "sink-inputs"],
            capture_output=True,
            text=True
        )
        streams = json.loads(result.stdout)
        apps = {}

        for stream in streams:
            props = stream.get("properties", {})
            proc_name = props.get("application.process.binary") or props.get("application.name") or "Unknown App"

            # Volume
            vol_raw = list(stream["volume"].values())[0]["value_percent"]
            volume = float(vol_raw.replace("%",""))/100 if isinstance(vol_raw,str) else vol_raw/100

            muted = stream["mute"]

            # Use browser-injected metadata if exists
            display_name = metadata_override.get(proc_name, proc_name)

            if proc_name not in apps:
                apps[proc_name] = {
                    "id_list": [stream["index"]],
                    "name": display_name,
                    "volume": volume,
                    "muted": muted
                }
            else:
                apps[proc_name]["id_list"].append(stream["index"])
                apps[proc_name]["volume"] = volume
                apps[proc_name]["muted"] = muted
                apps[proc_name]["name"] = display_name

        return apps
    except Exception as e:
        print("ERROR get_apps:", e)
        return {}

# --- Flask routes ---
@app.route("/")
def index():
    return send_from_directory("web", "index.html")

@app.route("/script.js")
def script():
    return send_from_directory("web", "script.js")

@app.route("/style.css")
def style():
    return send_from_directory("web", "style.css")

@app.route("/apps")
def apps():
    return jsonify(list(apps_cache.values()))

@app.route("/volume", methods=["POST"])
def volume():
    data = request.json
    proc = data["proc"]
    vol = float(data["volume"])
    desired_volumes[proc] = vol

    # apply to all sink-inputs of this process
    ids = apps_cache.get(proc, {}).get("id_list", [])
    for idx in ids:
        subprocess.run(["pactl", "set-sink-input-volume", str(idx), f"{int(vol*100)}%"])
    return "ok"

@app.route("/mute", methods=["POST"])
def mute():
    data = request.json
    proc = data["proc"]
    m = data["mute"]
    ids = apps_cache.get(proc, {}).get("id_list", [])
    for idx in ids:
        subprocess.run(["pactl", "set-sink-input-mute", str(idx), "1" if m else "0"])
    return "ok"

@app.route("/app_metadata", methods=["POST"])
def app_metadata():
    data = request.json
    proc = data.get("process")
    title = data.get("title")
    if proc and title:
        metadata_override[proc] = title
    return "ok"

# --- Background threads ---
def updater():
    global apps_cache
    while True:
        apps_cache = get_apps()
        time.sleep(0.25)

def event_listener():
    proc = subprocess.Popen(["pactl","subscribe"], stdout=subprocess.PIPE, text=True)
    global apps_cache
    for line in proc.stdout:
        if "sink-input" in line:
            apps_cache = get_apps()

def enforce_volumes():
    while True:
        for proc, vol in desired_volumes.items():
            ids = apps_cache.get(proc, {}).get("id_list", [])
            for idx in ids:
                subprocess.run(["pactl","set-sink-input-volume", str(idx), f"{int(vol*100)}%"])
        time.sleep(0.2)

# Start background threads
threading.Thread(target=updater, daemon=True).start()
threading.Thread(target=event_listener, daemon=True).start()
threading.Thread(target=enforce_volumes, daemon=True).start()

apps_cache = get_apps()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
const sliders = {};
const buttons = {};
const container = document.getElementById("apps");

async function loadApps() {
    try {
        const res = await fetch("/apps");
        const apps = await res.json();
        const currentProcs = apps.map(a=>a.name);

        // Remove gone apps
        Object.keys(sliders).forEach(proc=>{
            if (!currentProcs.includes(proc)) {
                sliders[proc].parentElement.remove();
                delete sliders[proc];
                delete buttons[proc];
            }
        });

        // Add/update apps
        apps.forEach(app=>{
            const proc = app.name;
            if (!sliders[proc]) {
                const div = document.createElement("div");
                div.className="app";

                const label = document.createElement("label");
                label.innerText = app.name;

                const slider = document.createElement("input");
                slider.type="range";
                slider.min=0;
                slider.max=1;
                slider.step=0.01;
                slider.value=app.volume;
                slider.oninput = ()=>sendVolume(proc, slider.value);

                const btn = document.createElement("button");
                btn.innerText = app.muted ? "Unmute":"Mute";
                btn.onclick = ()=>{
                    const mute = btn.innerText==="Mute";
                    fetch("/mute",{
                        method:"POST",
                        headers:{"Content-Type":"application/json"},
                        body:JSON.stringify({proc:proc, mute:mute})
                    });
                    btn.innerText = mute?"Unmute":"Mute";
                }

                sliders[proc]=slider;
                buttons[proc]=btn;

                div.appendChild(label);
                div.appendChild(slider);
                div.appendChild(btn);
                container.appendChild(div);
            } else {
                const slider = sliders[proc];
                const btn = buttons[proc];
                if (!slider.matches(":active")) slider.value=app.volume;
                btn.innerText = app.muted?"Unmute":"Mute";
            }
        });

    } catch(e){
        console.log("Error loading apps:", e);
    }
}

// Poll every 0.25s
setInterval(loadApps, 250);

async function sendVolume(proc, value){
    try{
        await fetch("/volume",{
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify({proc:proc, volume:value})
        });
    }catch(e){console.log("Volume error", e);}
}